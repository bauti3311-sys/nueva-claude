package dev.bautista.spotlight

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.MediaStore.Files.FileColumns
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Toast
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.roundToInt

data class Result(
    val id: String,
    val title: String,
    val subtitle: String,
    val kind: String,
    val glyph: String,
    val score: Int,
    val appComponent: ComponentName? = null,
    val keepOpen: Boolean = false,
    val onLong: (() -> Unit)? = null,
    val action: () -> Unit
)

data class AppEntry(val label: String, val norm: String, val pkg: String, val component: ComponentName)

class SearchEngine(context: Context, private val prefs: Prefs) {

    private val ctx: Context = context.applicationContext
    private val pm = ctx.packageManager
    private val main = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newFixedThreadPool(3)
    private val actions = Actions(ctx)

    @Volatile private var apps: List<AppEntry> = emptyList()
    private val iconCache = HashMap<String, Drawable?>()
    private var seq = 0
    private val netCache = HashMap<String, Pair<Long, List<Result>>>()

    var onAppsLoaded: (() -> Unit)? = null

    private val urlRe = Regex("^(https?://)?([a-z0-9-]+\\.)+[a-z]{2,}(/\\S*)?$", RegexOption.IGNORE_CASE)
    private val otpRegexes = listOf(
        Regex("(?i)(?:c[oó]digo|code|clave|pin|token|verificaci[oó]n)\\D{0,40}?(\\d{4,8})"),
        Regex("(?i)(\\d{4,8})\\D{0,25}(?:es tu|is your|es el c[oó]digo)")
    )

    // ------------------------------------------------------------------ apps

    fun refreshApps() {
        io.execute {
            try {
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val list = pm.queryIntentActivities(i, 0)
                val out = ArrayList<AppEntry>()
                for (ri in list) {
                    val ai = ri.activityInfo ?: continue
                    if (ai.packageName == ctx.packageName) continue
                    val label = ri.loadLabel(pm).toString()
                    out.add(AppEntry(label, Txt.norm(label), ai.packageName, ComponentName(ai.packageName, ai.name)))
                }
                apps = out.distinctBy { it.component }.sortedBy { it.norm }
                main.post { onAppsLoaded?.invoke() }
            } catch (e: Exception) {
            }
        }
    }

    fun icon(c: ComponentName): Drawable? {
        val k = c.flattenToString()
        if (iconCache.containsKey(k)) return iconCache[k]
        val d = try { pm.getActivityIcon(c) } catch (e: Exception) { null }
        iconCache[k] = d
        return d
    }

    private fun launch(a: AppEntry) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(a.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        ctx.startActivity(i)
    }

    private fun appResult(a: AppEntry, score: Int) = Result(
        id = "app:${a.pkg}", title = a.label, subtitle = "Aplicación · mantené presionado para ver info",
        kind = "App", glyph = "", score = score, appComponent = a.component,
        onLong = { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
        action = { prefs.bump("app:${a.pkg}"); launch(a) }
    )

    private fun searchApps(n: String): List<Result> {
        val out = ArrayList<Result>()
        for (a in apps) {
            val s = Txt.score(a.norm, n)
            if (s <= 0) continue
            out.add(appResult(a, s + minOf(prefs.usage("app:${a.pkg}") * 15, 150)))
        }
        return out
    }

    private fun suggestedApps(): List<Result> =
        apps.filter { prefs.usage("app:${it.pkg}") > 0 }
            .sortedByDescending { prefs.usage("app:${it.pkg}") }
            .take(8)
            .mapIndexed { i, a -> appResult(a, 900 - i) }

    // ------------------------------------------------------------------ portapapeles

    fun captureClipboard() {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            val t = clip.getItemAt(0).coerceToText(ctx)?.toString()?.trim().orEmpty()
            if (t.isNotEmpty() && t.length < 4000) ClipStore.add(t)
        } catch (e: Exception) {
        }
    }

    private fun copy(text: String, toast: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Spotlight", text))
        ClipStore.add(text)
        Toast.makeText(ctx, toast, Toast.LENGTH_SHORT).show()
    }

    private fun clips(n: String): List<Result> {
        val all = ClipStore.all()
        val listAll = n.startsWith("clip") || n.startsWith("portapapeles") || n == "pegar"
        val out = ArrayList<Result>()
        for ((i, t) in all.withIndex()) {
            val s = if (listAll) 600 - i else if (n.length >= 3 && Txt.norm(t).contains(n)) 450 - i else 0
            if (s <= 0) continue
            out.add(clipResult(t, s))
            if (out.size >= 6) break
        }
        return out
    }

    private fun clipResult(t: String, score: Int) = Result(
        id = "clip:${t.hashCode()}", title = t.replace('\n', ' ').take(80),
        subtitle = "Portapapeles · tocá para copiar de nuevo", kind = "Portapapeles", glyph = "📋",
        score = score, action = { copy(t, "Copiado") }
    )

    // ------------------------------------------------------------------ notificaciones reales

    private fun extractOtp(text: String): String? {
        for (r in otpRegexes) {
            val m = r.find(text)
            if (m != null) return m.groupValues[1]
        }
        return null
    }

    private fun notifResult(it: NotifItem, score: Int) = Result(
        id = "notif:${it.key}", title = it.title.ifBlank { it.app },
        subtitle = "${it.app} · ${it.text}".take(120), kind = "Notificación", glyph = "🔔", score = score,
        action = {
            try {
                val pi = it.intent
                if (pi != null) pi.send() else {
                    val li = pm.getLaunchIntentForPackage(it.pkg)
                    if (li != null) ctx.startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            } catch (e: Exception) {
                val li = pm.getLaunchIntentForPackage(it.pkg)
                if (li != null) ctx.startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    )

    private fun otpResults(max: Int, maxAgeMs: Long, baseScore: Int): List<Result> {
        val now = System.currentTimeMillis()
        val out = ArrayList<Result>()
        for (it in NotifListener.items()) {
            if (now - it.time > maxAgeMs) continue
            val code = extractOtp(it.title + " " + it.text) ?: continue
            out.add(
                Result(
                    id = "otp:${it.key}", title = "Código $code", subtitle = "${it.app} · tocá para copiar",
                    kind = "Código", glyph = "🔑", score = baseScore - out.size,
                    action = { copy(code, "Código copiado") }
                )
            )
            if (out.size >= max) break
        }
        return out
    }

    private fun notifs(n: String, blank: Boolean): List<Result> {
        val items = NotifListener.items()
        val out = ArrayList<Result>()
        if (blank) {
            out += otpResults(1, 10 * 60 * 1000L, 1000)
            for ((i, it) in items.take(3).withIndex()) out.add(notifResult(it, 700 - i))
            return out
        }
        val listAll = n.startsWith("notif")
        if (listAll && !Perms.listener(ctx)) {
            out.add(
                Result(
                    id = "notif:perm", title = "Activar acceso a notificaciones",
                    subtitle = "Necesario para ver tus notificaciones reales", kind = "Permiso", glyph = "🔔",
                    score = 800, action = { ctx.startActivity(Perms.listenerIntent()) }
                )
            )
        }
        if (n in listOf("codigo", "otp", "2fa", "code", "clave", "verificacion")) {
            out += otpResults(3, 60 * 60 * 1000L, 1500)
        }
        for ((i, it) in items.take(60).withIndex()) {
            val hay = Txt.norm(it.app + " " + it.title + " " + it.text)
            val s = if (listAll) 450 - i else if (n.length >= 3 && hay.contains(n)) 400 - i else 0
            if (s > 0) out.add(notifResult(it, s))
            if (out.size >= 8) break
        }
        return out
    }

    // ------------------------------------------------------------------ contactos / calendario / archivos (hilo secundario)

    private fun contacts(t: String): List<Result> {
        if (t.length < 2 || !Perms.contacts(ctx)) return emptyList()
        val out = ArrayList<Result>()
        val seen = HashSet<Long>()
        val P = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val proj = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val n = Txt.norm(t)
        ctx.contentResolver.query(
            P, proj, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$t%"),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
        )?.use { c ->
            while (c.moveToNext() && out.size < 6) {
                val id = c.getLong(0)
                if (!seen.add(id)) continue
                val lookup = c.getString(1) ?: ""
                val name = c.getString(2) ?: continue
                val num = c.getString(3) ?: ""
                val s = maxOf(Txt.score(Txt.norm(name), n), 400) - 50
                out.add(
                    Result(
                        id = "contact:$id", title = name, subtitle = "$num · mantené presionado para llamar",
                        kind = "Contacto", glyph = "👤", score = s,
                        onLong = { ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                        action = {
                            val u = ContactsContract.Contacts.getLookupUri(id, lookup)
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    )
                )
            }
        }
        return out
    }

    private fun events(t: String, upcomingOnly: Boolean, limit: Int): List<Result> {
        if (!Perms.calendar(ctx)) return emptyList()
        val begin = System.currentTimeMillis()
        val end = begin + 45L * 24 * 3600 * 1000
        val proj = arrayOf(
            CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY,
            CalendarContract.Instances.EVENT_LOCATION
        )
        val out = ArrayList<Result>()
        val dfTime = SimpleDateFormat("EEE d MMM · HH:mm", Locale.getDefault())
        val dfDay = SimpleDateFormat("EEE d MMM", Locale.getDefault()).apply { timeZone = TimeZone.getTimeZone("UTC") }
        val cur = if (upcomingOnly) CalendarContract.Instances.query(ctx.contentResolver, proj, begin, end)
        else CalendarContract.Instances.query(ctx.contentResolver, proj, begin, end, t)
        cur?.use { c ->
            while (c.moveToNext() && out.size < limit) {
                val id = c.getLong(0)
                val title = c.getString(1) ?: "(sin título)"
                val b = c.getLong(2)
                val allDay = c.getInt(3) == 1
                val loc = c.getString(4) ?: ""
                val whenTxt = if (allDay) dfDay.format(Date(b)) else dfTime.format(Date(b))
                out.add(
                    Result(
                        id = "event:$id:$b", title = title,
                        subtitle = if (loc.isBlank()) whenTxt else "$whenTxt · $loc",
                        kind = "Evento", glyph = "📅", score = (if (upcomingOnly) 800 else 650) - out.size,
                        action = {
                            val u = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id)
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, u)
                                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, b)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    )
                )
            }
        }
        return out
    }

    private fun files(t: String): List<Result> {
        if (t.length < 2 || !Perms.files(ctx)) return emptyList()
        val out = ArrayList<Result>()
        val uri = MediaStore.Files.getContentUri("external")
        val proj = arrayOf(FileColumns._ID, FileColumns.DISPLAY_NAME, FileColumns.MIME_TYPE, FileColumns.SIZE, FileColumns.DATE_MODIFIED)
        val sel = "${FileColumns.DISPLAY_NAME} LIKE ? AND ${FileColumns.MIME_TYPE} IS NOT NULL"
        ctx.contentResolver.query(uri, proj, sel, arrayOf("%$t%"), "${FileColumns.DATE_MODIFIED} DESC")?.use { c ->
            while (c.moveToNext() && out.size < 6) {
                val id = c.getLong(0)
                val name = c.getString(1) ?: continue
                val mime = c.getString(2) ?: "*/*"
                val size = c.getLong(3)
                val mod = c.getLong(4) * 1000
                val u = ContentUris.withAppendedId(uri, id)
                val sub = Formatter.formatShortFileSize(ctx, size) + " · " +
                    SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(mod))
                out.add(
                    Result(
                        id = "file:$id", title = name, subtitle = sub, kind = "Archivo", glyph = "📄",
                        score = 420 - out.size,
                        action = {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW).setDataAndType(u, mime)
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    )
                )
            }
        }
        return out
    }

    // ------------------------------------------------------------------ red: dólar y clima reales

    private fun netTrigger(n: String): String? = when {
        n.startsWith("dolar") || n in listOf("usd", "blue", "mep", "ccl", "cotizacion", "cotizaciones", "divisas") -> "usd"
        n.startsWith("clima") || n.startsWith("tiempo") || n == "pronostico" || n.startsWith("weather") -> "weather"
        else -> null
    }

    private fun fetchNet(kind: String): List<Result> {
        val cached = netCache[kind]
        if (cached != null && System.currentTimeMillis() - cached.first < 10 * 60 * 1000L) return cached.second
        val nf = NumberFormat.getNumberInstance(Locale("es", "AR")).apply { maximumFractionDigits = 0 }
        val res: List<Result> = if (kind == "usd") {
            Net.dollars().mapIndexed { i, q ->
                val buy = q.buy?.let { "$" + nf.format(it) } ?: "—"
                val sell = q.sell?.let { "$" + nf.format(it) } ?: "—"
                Result(
                    id = "usd:${q.name}", title = "Dólar ${q.name}", subtitle = "Compra $buy · Venta $sell",
                    kind = "Cotización", glyph = "💵", score = 1900 - i,
                    action = { copy((q.sell ?: q.buy ?: 0.0).roundToInt().toString(), "Valor copiado") }
                )
            }
        } else {
            val loc = Net.location(ctx)
            if (loc == null) {
                listOf(
                    Result(
                        id = "wx:noloc", title = "Clima: falta la ubicación",
                        subtitle = if (Perms.location(ctx)) "Activá la ubicación del dispositivo y reintentá"
                        else "Concedé el permiso de ubicación en Spotlight Next",
                        kind = "Clima", glyph = "📍", score = 1900,
                        action = { ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    )
                )
            } else {
                val w = Net.weather(loc.latitude, loc.longitude)
                val d = Net.describe(w.code)
                listOf(
                    Result(
                        id = "wx:now", title = "${d.second} ${w.temp.roundToInt()}° · ${d.first}",
                        subtitle = "Sensación ${w.feels.roundToInt()}° · Máx ${w.max.roundToInt()}° / Mín ${w.min.roundToInt()}° · " +
                            "Lluvia ${w.rainPct}% · Viento ${w.windKmh.roundToInt()} km/h · Humedad ${w.humidity}%",
                        kind = "Clima", glyph = d.second, score = 1900,
                        action = { view("https://www.google.com/search?q=clima") }
                    )
                )
            }
        }
        netCache[kind] = Pair(System.currentTimeMillis(), res)
        return res
    }

    // ------------------------------------------------------------------ web

    private fun view(url: String) {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun web(t: String): List<Result> {
        val out = ArrayList<Result>()
        val enc = Uri.encode(t)
        if (urlRe.matches(t)) {
            val u = if (t.startsWith("http", true)) t else "https://$t"
            out.add(Result("web:url", "Abrir $t", "Enlace", "Web", "🌐", 1500, action = { view(u) }))
        }
        out.add(Result("web:g", "Buscar “$t” en Google", "Navegador", "Web", "🔍", 50, action = { view("https://www.google.com/search?q=$enc") }))
        out.add(Result("web:yt", "Buscar “$t” en YouTube", "Navegador / app de YouTube", "Web", "▶️", 49, action = { view("https://www.youtube.com/results?search_query=$enc") }))
        out.add(Result("web:map", "Buscar “$t” en mapas", "App de mapas", "Web", "🗺️", 48, action = { view("geo:0,0?q=$enc") }))
        return out
    }

    // ------------------------------------------------------------------ búsqueda

    private fun fast(q: String): MutableList<Result> {
        val out = ArrayList<Result>()
        val t = q.trim()
        if (t.isEmpty()) {
            out += notifs("", true)
            out += suggestedApps()
            ClipStore.all().firstOrNull()?.let { out.add(clipResult(it, 650)) }
            return out
        }
        val n = Txt.norm(t)
        Calc.tryEval(t)?.let { r ->
            out.add(
                Result(
                    id = "calc", title = "= $r", subtitle = "$t · tocá para copiar el resultado",
                    kind = "Cálculo", glyph = "🧮", score = 2000, action = { copy(r, "Resultado copiado") }
                )
            )
        }
        out += searchApps(n)
        out += actions.quick(n)
        out += actions.settings(n)
        out += notifs(n, false)
        out += clips(n)
        out += web(t)
        if (netTrigger(n) != null) {
            out.add(Result("net:loading", "Consultando…", "Datos en vivo", "Red", "⏳", 1950, keepOpen = true, action = {}))
        }
        return out
    }

    private fun finish(list: List<Result>): List<Result> =
        list.distinctBy { it.id }.sortedByDescending { it.score }.take(30)

    /** [publish] se llama en el hilo principal, primero con lo rápido y luego con lo lento. */
    fun search(q: String, publish: (List<Result>) -> Unit) {
        val my = ++seq
        val acc = fast(q)
        publish(finish(acc))
        val t = q.trim()
        val n = Txt.norm(t)

        if (t.isEmpty() || t.length >= 2) {
            io.execute {
                val slow = ArrayList<Result>()
                try {
                    if (t.isEmpty()) {
                        slow += events("", true, 3)
                    } else {
                        slow += contacts(t)
                        val wantsAgenda = n in listOf("agenda", "calendario", "eventos", "hoy", "mañana", "manana")
                        slow += events(t, wantsAgenda, if (wantsAgenda) 8 else 4)
                        slow += files(t)
                    }
                } catch (e: Exception) {
                }
                if (slow.isNotEmpty()) {
                    main.post {
                        if (my == seq) { acc.addAll(slow); publish(finish(acc)) }
                    }
                }
            }
        }

        val trig = netTrigger(n)
        if (trig != null) {
            io.execute {
                val res: List<Result> = try {
                    fetchNet(trig)
                } catch (e: Exception) {
                    listOf(
                        Result(
                            id = "net:err", title = "Sin conexión o servicio no disponible",
                            subtitle = "No se pudo obtener los datos en vivo", kind = "Red", glyph = "⚠️",
                            score = 1900, action = {}
                        )
                    )
                }
                main.post {
                    if (my == seq) {
                        acc.removeAll { it.id == "net:loading" }
                        acc.addAll(res)
                        publish(finish(acc))
                    }
                }
            }
        }
    }
}
