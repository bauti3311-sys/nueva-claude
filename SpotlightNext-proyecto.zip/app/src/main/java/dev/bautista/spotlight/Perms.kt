package dev.bautista.spotlight

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings

object Perms {
    fun has(ctx: Context, p: String): Boolean =
        ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun overlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun postNotifications(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || has(ctx, Manifest.permission.POST_NOTIFICATIONS)

    fun contacts(ctx: Context): Boolean = has(ctx, Manifest.permission.READ_CONTACTS)
    fun calendar(ctx: Context): Boolean = has(ctx, Manifest.permission.READ_CALENDAR)
    fun location(ctx: Context): Boolean = has(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)

    fun files(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else has(ctx, Manifest.permission.READ_EXTERNAL_STORAGE)

    fun writeSettings(ctx: Context): Boolean = Settings.System.canWrite(ctx)

    fun batteryUnrestricted(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    fun listener(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { ComponentName.unflattenFromString(it)?.packageName == ctx.packageName }
    }

    fun pkgUri(ctx: Context): Uri = Uri.parse("package:${ctx.packageName}")

    fun overlayIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri(ctx)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun writeSettingsIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri(ctx)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun listenerIntent(): Intent =
        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun allFilesIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkgUri(ctx)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun batteryIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri(ctx)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun appInfoIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri(ctx)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
