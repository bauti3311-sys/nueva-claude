package dev.bautista.spotlight

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadata
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

/** La barra Spotlight: buscador + resultados + reproductor. Se dibuja a pantalla completa con fondo tenue. */
class SpotlightPanel(
    context: Context,
    private val engine: SearchEngine,
    private val onClose: () -> Unit
) : FrameLayout(context) {

    private class MaxHeightScroll(c: Context) : ScrollView(c) {
        var maxPx = 800
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxPx, MeasureSpec.AT_MOST))
        }
    }

    private val card = LinearLayout(context)
    private val input = EditText(context)
    private val info = TextView(context)
    private val scroll = MaxHeightScroll(context)
    private val list = LinearLayout(context)
    private val player = LinearLayout(context)
    private val playerText = TextView(context)
    private val btnPrev = TextView(context)
    private val btnPlay = TextView(context)
    private val btnNext = TextView(context)

    private var results: List<Result> = emptyList()
    private var sel = 0
    private var bottomInset = 0
    private var topGap = 0
    private var focusedOnce = false
    private val handler = Handler(Looper.getMainLooper())
    private val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    init {
        build()
    }

    private fun build() {
        setBackgroundColor(Color.argb(120, 0, 0, 0))
        isClickable = true
        setOnClickListener { close() }
        isFocusableInTouchMode = false

        val dm = resources.displayMetrics
        val cardW = minOf((dm.widthPixels * 0.92f).toInt(), dp(640))
        topGap = (dm.heightPixels * 0.07f).toInt()

        card.orientation = LinearLayout.VERTICAL
        card.background = Ui.round(Ui.BG, dp(24).toFloat(), Ui.STROKE, dp(1))
        card.elevation = dp(16).toFloat()
        card.isClickable = true
        val lp = LayoutParams(cardW, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        lp.topMargin = topGap
        addView(card, lp)

        // --- fila de búsqueda
        val head = LinearLayout(context)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(18), dp(10), dp(10), dp(4))

        val glyph = TextView(context)
        glyph.text = "🔎"
        glyph.textSize = 20f
        head.addView(glyph)

        input.hint = "Buscar apps, contactos, archivos, cuentas…"
        input.setHintTextColor(Ui.MUTED)
        input.setTextColor(Ui.TEXT)
        input.textSize = 20f
        input.background = null
        input.setSingleLine(true)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        input.imeOptions = EditorInfo.IME_ACTION_GO
        input.setPadding(dp(12), dp(10), dp(8), dp(10))
        head.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val x = TextView(context)
        x.text = "✕"
        x.textSize = 18f
        x.setTextColor(Ui.MUTED)
        x.setPadding(dp(14), dp(10), dp(14), dp(10))
        x.setOnClickListener { close() }
        head.addView(x)
        card.addView(head)

        info.textSize = 12f
        info.setTextColor(Ui.MUTED)
        info.setPadding(dp(20), 0, dp(20), dp(8))
        card.addView(info)

        val div = View(context)
        div.setBackgroundColor(Ui.STROKE)
        card.addView(div, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))

        // --- resultados
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(4), 0, dp(4))
        scroll.addView(list, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        scroll.isVerticalScrollBarEnabled = false
        card.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // --- reproductor (solo si hay una sesión multimedia real)
        player.orientation = LinearLayout.HORIZONTAL
        player.gravity = Gravity.CENTER_VERTICAL
        player.setPadding(dp(18), dp(6), dp(8), dp(6))
        player.visibility = View.GONE
        player.setBackgroundColor(Color.argb(40, 255, 255, 255))
        val note = TextView(context)
        note.text = "🎵"
        note.textSize = 18f
        player.addView(note)
        playerText.setTextColor(Ui.TEXT)
        playerText.textSize = 14f
        playerText.setSingleLine(true)
        playerText.ellipsize = TextUtils.TruncateAt.END
        playerText.setPadding(dp(10), 0, dp(6), 0)
        player.addView(playerText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        for ((b, s) in listOf(btnPrev to "⏮", btnPlay to "⏯", btnNext to "⏭")) {
            b.text = s
            b.textSize = 22f
            b.setTextColor(Ui.TEXT)
            b.setPadding(dp(12), dp(8), dp(12), dp(8))
            player.addView(b)
        }
        card.addView(player)

        // --- eventos
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { runSearch() }
        })
        input.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                results.getOrNull(sel)?.let { activate(it) }
                true
            } else false
        }
        input.setOnKeyListener { _, keyCode, e ->
            if (e.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_DOWN -> { move(1); true }
                    KeyEvent.KEYCODE_DPAD_UP -> { move(-1); true }
                    KeyEvent.KEYCODE_TAB -> { move(if (e.isShiftPressed) -1 else 1); true }
                    else -> false
                }
            } else false
        }

        engine.onAppsLoaded = { runSearch() }
        runSearch()
        refreshInfo()
        refreshPlayer()
    }

    // ---------------------------------------------------------------- búsqueda y render

    private fun runSearch() {
        engine.search(input.text.toString()) { r ->
            val first = results.isEmpty()
            results = r
            if (sel >= r.size) sel = 0
            if (first || input.text.isNotEmpty()) sel = 0
            render()
        }
    }

    private fun render() {
        list.removeAllViews()
        if (results.isEmpty()) {
            val t = TextView(context)
            t.text = if (input.text.isBlank()) "Escribí para buscar. Probá: «dolar», «clima», «2+2», «notif», «agenda»."
            else "Sin resultados"
            t.setTextColor(Ui.MUTED)
            t.textSize = 14f
            t.setPadding(dp(20), dp(16), dp(20), dp(16))
            list.addView(t)
            return
        }
        for ((i, r) in results.withIndex()) list.addView(rowView(r, i))
        scroll.scrollTo(0, 0)
    }

    private fun rowView(r: Result, i: Int): View {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(12), dp(8), dp(14), dp(8))
        row.minimumHeight = dp(58)
        row.background = if (i == sel) Ui.round(Ui.ACCENT_SOFT, dp(14).toFloat()) else null

        val box = FrameLayout(context)
        val comp = r.appComponent
        if (comp != null) {
            val iv = ImageView(context)
            iv.setImageDrawable(engine.icon(comp))
            box.addView(iv, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        } else {
            val g = TextView(context)
            g.text = r.glyph
            g.textSize = 20f
            g.gravity = Gravity.CENTER
            g.background = Ui.round(Color.argb(40, 255, 255, 255), dp(12).toFloat())
            box.addView(g, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        }
        row.addView(box, LinearLayout.LayoutParams(dp(46), dp(46)))

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, dp(8), 0)
        val title = TextView(context)
        title.text = r.title
        title.setTextColor(Ui.TEXT)
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setSingleLine(true)
        title.ellipsize = TextUtils.TruncateAt.END
        col.addView(title)
        val sub = TextView(context)
        sub.text = r.subtitle
        sub.setTextColor(Ui.MUTED)
        sub.textSize = 12f
        sub.maxLines = 2
        sub.ellipsize = TextUtils.TruncateAt.END
        col.addView(sub)
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val badge = TextView(context)
        badge.text = r.kind
        badge.textSize = 10f
        badge.setTextColor(Ui.ACCENT)
        badge.setPadding(dp(8), dp(3), dp(8), dp(3))
        badge.background = Ui.round(Color.argb(30, 16, 185, 129), dp(8).toFloat())
        row.addView(badge)

        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(8), dp(2), dp(8), dp(2))
        row.layoutParams = lp
        row.setOnClickListener { activate(r) }
        row.setOnLongClickListener {
            val f = r.onLong
            if (f != null) {
                try { f() } catch (e: Exception) { toast(e) }
                close()
                true
            } else false
        }
        return row
    }

    private fun highlight() {
        for (i in 0 until list.childCount) {
            list.getChildAt(i).background = if (i == sel) Ui.round(Ui.ACCENT_SOFT, dp(14).toFloat()) else null
        }
        val v = list.getChildAt(sel) ?: return
        scroll.post {
            if (v.top < scroll.scrollY) scroll.scrollTo(0, v.top)
            else if (v.bottom > scroll.scrollY + scroll.height) scroll.scrollTo(0, v.bottom - scroll.height)
        }
    }

    private fun move(d: Int) {
        if (results.isEmpty()) return
        sel = (sel + d).coerceIn(0, results.size - 1)
        highlight()
    }

    private fun activate(r: Result) {
        try {
            r.action()
        } catch (e: Exception) {
            toast(e)
        }
        if (r.keepOpen) handler.postDelayed({ runSearch() }, 250) else close()
    }

    private fun toast(e: Exception) {
        val m = if (e is android.content.ActivityNotFoundException) "No hay una app para abrir esto" else (e.message ?: "Error")
        Toast.makeText(context, m, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- estado del dispositivo / reproductor

    private fun refreshInfo() {
        val bi = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (lvl >= 0) lvl * 100 / scale else -1
        val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
        val day = java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault()).format(Date())
        info.text = (if (pct >= 0) "🔋 $pct%${if (charging) " ⚡" else ""}  ·  " else "") + "$day  $time"
    }

    private fun refreshPlayer() {
        val c = NotifListener.activeController(context)
        if (c == null) {
            player.visibility = View.GONE
            return
        }
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Reproduciendo"
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val playing = c.playbackState?.state == PlaybackState.STATE_PLAYING
        playerText.text = if (artist.isBlank()) title else "$title — $artist"
        btnPlay.text = if (playing) "⏸" else "▶"
        btnPrev.setOnClickListener { try { c.transportControls.skipToPrevious() } catch (e: Exception) {}; later() }
        btnNext.setOnClickListener { try { c.transportControls.skipToNext() } catch (e: Exception) {}; later() }
        btnPlay.setOnClickListener {
            try { if (playing) c.transportControls.pause() else c.transportControls.play() } catch (e: Exception) {}
            later()
        }
        player.visibility = View.VISIBLE
    }

    private fun later() {
        handler.postDelayed({ refreshPlayer() }, 400)
    }

    // ---------------------------------------------------------------- ventana / teclado

    private fun recalc() {
        val h = height
        if (h <= 0) return
        val used = dp(120) + (if (player.visibility == View.VISIBLE) dp(52) else 0)
        val avail = h - topGap - bottomInset - used - dp(24)
        scroll.maxPx = avail.coerceIn(dp(100), (h * 0.62f).toInt())
        scroll.requestLayout()
    }

    @Suppress("DEPRECATION")
    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        bottomInset = insets.systemWindowInsetBottom
        recalc()
        return super.onApplyWindowInsets(insets)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        recalc()
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus && !focusedOnce) {
            focusedOnce = true
            engine.captureClipboard()   // lectura real del portapapeles (requiere foco)
            refreshInfo()
            refreshPlayer()
            runSearch()
            input.requestFocus()
            handler.postDelayed({ imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) }, 150)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) close()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    fun close() {
        handler.removeCallbacksAndMessages(null)
        try { imm.hideSoftInputFromWindow(windowToken, 0) } catch (e: Exception) {}
        engine.onAppsLoaded = null
        onClose()
    }
}
