package dev.bautista.spotlight

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val p = Prefs(ctx)
            if (p.autostart && p.serviceWanted && Settings.canDrawOverlays(ctx)) {
                OverlayService.start(ctx, false)
            }
        }
    }
}
