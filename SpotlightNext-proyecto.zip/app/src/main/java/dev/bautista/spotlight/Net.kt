package dev.bautista.spotlight

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.function.Consumer

object Net {
    data class Quote(val name: String, val buy: Double?, val sell: Double?)

    data class Weather(
        val temp: Double, val feels: Double, val code: Int, val windKmh: Double,
        val humidity: Int, val max: Double, val min: Double, val rainPct: Int
    )

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "SpotlightNext/4.0")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Cotizaciones reales desde dolarapi.com */
    fun dollars(): List<Quote> {
        val arr = JSONArray(get("https://dolarapi.com/v1/dolares"))
        val order = listOf("oficial", "blue", "bolsa", "contadoconliqui", "tarjeta", "mayorista", "cripto")
        val out = ArrayList<Pair<Int, Quote>>()
        for (i in 0 until arr.length()) {
            val o: JSONObject = arr.getJSONObject(i)
            val casa = o.optString("casa")
            val idx = order.indexOf(casa)
            if (idx < 0) continue
            val buy = if (o.isNull("compra")) null else o.optDouble("compra")
            val sell = if (o.isNull("venta")) null else o.optDouble("venta")
            out.add(Pair(idx, Quote(o.optString("nombre", casa), buy, sell)))
        }
        return out.sortedBy { it.first }.map { it.second }
    }

    /** Clima real desde Open-Meteo (sin clave). */
    fun weather(lat: Double, lon: Double): Weather {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m" +
            "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=auto&forecast_days=1"
        val root = JSONObject(get(url))
        val cur = root.getJSONObject("current")
        val daily = root.getJSONObject("daily")
        return Weather(
            temp = cur.getDouble("temperature_2m"),
            feels = cur.getDouble("apparent_temperature"),
            code = cur.getInt("weather_code"),
            windKmh = cur.getDouble("wind_speed_10m"),
            humidity = cur.getInt("relative_humidity_2m"),
            max = daily.getJSONArray("temperature_2m_max").getDouble(0),
            min = daily.getJSONArray("temperature_2m_min").getDouble(0),
            rainPct = daily.getJSONArray("precipitation_probability_max").optInt(0, 0)
        )
    }

    fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> Pair("Despejado", "☀️")
        1 -> Pair("Mayormente despejado", "🌤️")
        2 -> Pair("Parcialmente nublado", "⛅")
        3 -> Pair("Nublado", "☁️")
        45, 48 -> Pair("Niebla", "🌫️")
        51, 53, 55, 56, 57 -> Pair("Llovizna", "🌦️")
        61, 63, 65, 66, 67 -> Pair("Lluvia", "🌧️")
        71, 73, 75, 77 -> Pair("Nieve", "❄️")
        80, 81, 82 -> Pair("Chubascos", "🌦️")
        85, 86 -> Pair("Nevadas", "❄️")
        95, 96, 99 -> Pair("Tormenta", "⛈️")
        else -> Pair("Clima", "🌡️")
    }

    /** Última ubicación conocida (aproximada). Si no hay, pide una al sistema (Android 11+). */
    @SuppressLint("MissingPermission")
    fun location(ctx: Context): Location? {
        if (!Perms.location(ctx)) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        try {
            for (p in lm.getProviders(true)) {
                val l = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
                if (l != null && (best == null || l.time > best.time)) best = l
            }
        } catch (e: Exception) {
        }
        if (best != null) return best
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val latch = CountDownLatch(1)
                var res: Location? = null
                lm.getCurrentLocation(
                    LocationManager.NETWORK_PROVIDER, null, Executors.newSingleThreadExecutor(),
                    Consumer<Location> { l -> res = l; latch.countDown() }
                )
                latch.await(6, TimeUnit.SECONDS)
                return res
            } catch (e: Exception) {
            }
        }
        return null
    }
}
