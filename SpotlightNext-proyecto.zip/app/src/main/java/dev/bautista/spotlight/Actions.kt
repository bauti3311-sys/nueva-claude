package dev.bautista.spotlight

import android.content.Context
import android.content.Intent
import android.bluetooth.BluetoothManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import kotlin.math.roundToInt

/** Acciones reales del sistema: volumen, brillo, rotación, linterna y atajos a Ajustes. */
class Actions(private val ctx: Context) {

    companion object {
        @Volatile var torchOn = false
    }

    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private class Q(
        val id: String,
        val title: String,
        val keys: List<String>,
        val glyph: String,
        val keep: Boolean,
        val sub: () -> String,
        val act: () -> Unit
    )

    private class S(val title: String, val action: String, val keys: List<String>)

    private val shortcuts = listOf(
        S("Ajustes del sistema", Settings.ACTION_SETTINGS, listOf("configuracion", "ajustes", "settings")),
        S("Ajustes de Wi-Fi", Settings.ACTION_WIFI_SETTINGS, listOf("wifi", "internet", "red")),
        S("Ajustes de Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS, listOf("bluetooth", "bt", "auriculares")),
        S("Ajustes de pantalla", Settings.ACTION_DISPLAY_SETTINGS, listOf("pantalla", "display", "brillo")),
        S("Ajustes de sonido", Settings.ACTION_SOUND_SETTINGS, listOf("sonido", "volumen", "tono")),
        S("Batería", Settings.ACTION_BATTERY_SAVER_SETTINGS, listOf("bateria", "ahorro", "energia")),
        S("Almacenamiento", Settings.ACTION_INTERNAL_STORAGE_SETTINGS, listOf("almacenamiento", "espacio", "memoria")),
        S("Aplicaciones instaladas", Settings.ACTION_APPLICATION_SETTINGS, listOf("aplicaciones", "apps", "desinstalar")),
        S("Accesibilidad", Settings.ACTION_ACCESSIBILITY_SETTINGS, listOf("accesibilidad")),
        S("Opciones de desarrollador", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, listOf("desarrollador", "developer", "adb", "depuracion")),
        S("Fecha y hora", Settings.ACTION_DATE_SETTINGS, listOf("fecha", "hora", "reloj")),
        S("Idioma", Settings.ACTION_LOCALE_SETTINGS, listOf("idioma", "language", "locale")),
        S("Ubicación", Settings.ACTION_LOCATION_SOURCE_SETTINGS, listOf("ubicacion", "gps", "location")),
        S("Modo avión", Settings.ACTION_AIRPLANE_MODE_SETTINGS, listOf("avion", "airplane")),
        S("VPN", Settings.ACTION_VPN_SETTINGS, listOf("vpn")),
        S("Teclado", Settings.ACTION_INPUT_METHOD_SETTINGS, listOf("teclado", "keyboard")),
        S("Transmitir pantalla", Settings.ACTION_CAST_SETTINGS, listOf("cast", "transmitir", "chromecast"))
    )

    fun settings(n: String): List<Result> {
        if (n.length < 2) return emptyList()
        val out = ArrayList<Result>()
        for (s in shortcuts) {
            var sc = Txt.score(Txt.norm(s.title), n)
            for (k in s.keys) sc = maxOf(sc, Txt.score(k, n) - 100)
            if (sc >= 300) {
                out.add(
                    Result(
                        id = "set:${s.action}", title = s.title, subtitle = "Ajustes del sistema",
                        kind = "Ajuste", glyph = "⚙️", score = sc - 100,
                        action = { open(Intent(s.action)) }
                    )
                )
            }
        }
        return out
    }

    fun quick(n: String): List<Result> {
        if (n.length < 2) return emptyList()
        val out = ArrayList<Result>()
        for (q in items()) {
            var sc = Txt.score(Txt.norm(q.title), n)
            for (k in q.keys) sc = maxOf(sc, Txt.score(k, n) - 100)
            if (sc >= 300) {
                out.add(
                    Result(
                        id = q.id, title = q.title, subtitle = q.sub(), kind = "Acción",
                        glyph = q.glyph, score = sc - 50, keepOpen = q.keep, action = q.act
                    )
                )
            }
        }
        return out
    }

    private fun items(): List<Q> {
        val l = ArrayList<Q>()
        l.add(Q("vol_up", "Subir volumen", listOf("volumen", "sonido", "audio", "subir", "vol"), "🔊", true,
            { "Volumen multimedia: ${volPct()}%" },
            { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }))
        l.add(Q("vol_down", "Bajar volumen", listOf("volumen", "sonido", "audio", "bajar", "vol"), "🔉", true,
            { "Volumen multimedia: ${volPct()}%" },
            { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }))
        l.add(Q("vol_mute", "Silenciar o activar sonido", listOf("mute", "silenciar", "silencio", "volumen"), "🔇", true,
            { if (am.isStreamMute(AudioManager.STREAM_MUSIC)) "Ahora: silenciado" else "Ahora: con sonido" },
            { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI) }))

        for (pct in listOf(25, 50, 75, 100)) {
            l.add(Q("bri_$pct", "Brillo $pct%", listOf("brillo", "luz", "pantalla", "brightness"), "🔆", false,
                {
                    if (!Perms.writeSettings(ctx)) "Requiere el permiso «Modificar ajustes del sistema»"
                    else "Brillo actual: ${curBrightness()}%"
                },
                { setBrightness(pct) }))
        }

        l.add(Q("rot", "Rotación automática", listOf("rotar", "rotacion", "girar", "pantalla"), "🔄", true,
            {
                if (!Perms.writeSettings(ctx)) "Requiere el permiso «Modificar ajustes del sistema»"
                else if (autoRotate()) "Activada · tocá para desactivar" else "Desactivada · tocá para activar"
            },
            { toggleRotate() }))

        l.add(Q("wifi", "Wi-Fi", listOf("wifi", "internet", "red", "conexion"), "📶", false,
            { try { if ((ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled) "Activado · abrir panel" else "Desactivado · abrir panel" } catch (e: Exception) { "Abrir panel" } },
            { openWifiPanel() }))

        l.add(Q("bt", "Bluetooth", listOf("bluetooth", "bt", "auriculares", "parlante"), "🎧", false,
            {
                try {
                    val bm = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                    if (bm.adapter?.isEnabled == true) "Activado · abrir ajustes" else "Desactivado · abrir ajustes"
                } catch (e: Exception) { "Abrir ajustes" }
            },
            { open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }))

        if (torchId() != null) {
            l.add(Q("torch", "Linterna", listOf("linterna", "flash", "torch", "luz"), "🔦", true,
                { if (torchOn) "Encendida · tocá para apagar" else "Apagada · tocá para encender" },
                { toggleTorch() }))
        }
        return l
    }

    // ---------- helpers reales ----------

    private fun open(i: Intent) {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun openWifiPanel() {
        if (Build.VERSION.SDK_INT >= 29) open(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
        else open(Intent(Settings.ACTION_WIFI_SETTINGS))
    }

    private fun volPct(): Int {
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max).roundToInt()
    }

    private fun curBrightness(): Int =
        try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) * 100 / 255
        } catch (e: Settings.SettingNotFoundException) {
            -1
        }

    private fun setBrightness(pct: Int) {
        if (!Perms.writeSettings(ctx)) { open(Perms.writeSettingsIntent(ctx)); return }
        val cr = ctx.contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (pct * 255 / 100).coerceIn(1, 255))
    }

    private fun autoRotate(): Boolean =
        Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1

    private fun toggleRotate() {
        if (!Perms.writeSettings(ctx)) { open(Perms.writeSettingsIntent(ctx)); return }
        Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (autoRotate()) 0 else 1)
    }

    private fun torchId(): String? =
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.cameraIdList.firstOrNull { id ->
                val ch = cm.getCameraCharacteristics(id)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (e: Exception) {
            null
        }

    private fun toggleTorch() {
        val id = torchId() ?: return
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cm.setTorchMode(id, !torchOn)
        torchOn = !torchOn
    }
}
