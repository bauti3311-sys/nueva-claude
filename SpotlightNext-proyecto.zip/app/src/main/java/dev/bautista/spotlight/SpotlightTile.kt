package dev.bautista.spotlight

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Mosaico en los ajustes rápidos (panel que se baja arriba): abre la barra Spotlight. */
class SpotlightTile : TileService() {

    override fun onStartListening() {
        qsTile?.let {
            it.state = if (OverlayService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            it.updateTile()
        }
    }

    override fun onClick() {
        val i = Intent(this, ShowActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)
            try {
                TileService::class.java.getMethod("startActivityAndCollapse", PendingIntent::class.java).invoke(this, pi)
            } catch (e: Exception) {
                startActivity(i)
            }
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
