package dev.bautista.spotlight

import android.app.Notification
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class NotifItem(
    val key: String,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long,
    val intent: PendingIntent?
)

/**
 * Lee las notificaciones reales del sistema (requiere "Acceso a notificaciones")
 * y da acceso a las sesiones multimedia activas (Spotify, YouTube, etc.).
 */
class NotifListener : NotificationListenerService() {

    companion object {
        private val lock = Any()
        private var cache: List<NotifItem> = emptyList()

        fun items(): List<NotifItem> = synchronized(lock) { cache }

        fun controllers(ctx: Context): List<MediaController> {
            return try {
                val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
                msm.getActiveSessions(ComponentName(ctx, NotifListener::class.java))
            } catch (e: Exception) {
                emptyList()
            }
        }

        fun activeController(ctx: Context): MediaController? =
            controllers(ctx).firstOrNull {
                val st = it.playbackState?.state
                st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_PAUSED ||
                    st == PlaybackState.STATE_BUFFERING
            }
    }

    override fun onListenerConnected() {
        rebuild()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        rebuild()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        rebuild()
    }

    private fun rebuild() {
        val arr = try { activeNotifications } catch (e: Exception) { null } ?: return
        val pm = packageManager
        val out = ArrayList<NotifItem>()
        for (sbn in arr) {
            if (sbn.packageName == packageName) continue
            if (sbn.isOngoing) continue
            val n = sbn.notification
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) continue
            val ex = n.extras
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            if (title.isBlank() && text.isBlank()) continue
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
            } catch (e: Exception) {
                sbn.packageName
            }
            out.add(NotifItem(sbn.key, sbn.packageName, label, title, text, sbn.postTime, n.contentIntent))
        }
        synchronized(lock) { cache = out.sortedByDescending { it.time } }
    }
}
