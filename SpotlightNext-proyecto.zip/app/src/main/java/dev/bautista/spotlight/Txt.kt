package dev.bautista.spotlight

import java.text.Normalizer
import java.util.Locale

object Txt {
    private val accents = Regex("\\p{M}+")

    fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(accents, "").lowercase(Locale.ROOT)

    /** 0 = no coincide. Más alto = mejor coincidencia. Ambos argumentos ya normalizados. */
    fun score(name: String, q: String): Int {
        if (q.isEmpty()) return 0
        if (name == q) return 1000
        if (name.startsWith(q)) return 900 - minOf(name.length - q.length, 60)
        val words = name.split(' ', '-', '_', '.', '/', '(', ')')
        if (words.any { it.startsWith(q) }) return 700
        if (name.contains(q)) return 500
        if (q.length >= 3 && subseq(name, q)) return 300
        return 0
    }

    private fun subseq(h: String, n: String): Boolean {
        var i = 0
        for (c in h) {
            if (i < n.length && c == n[i]) i++
        }
        return i == n.length
    }
}

/** Historial del portapapeles: solo en memoria (no se guarda en disco por seguridad). */
object ClipStore {
    private val items = ArrayList<String>()

    @Synchronized
    fun add(t: String) {
        items.remove(t)
        items.add(0, t)
        while (items.size > 20) items.removeAt(items.size - 1)
    }

    @Synchronized
    fun all(): List<String> = ArrayList(items)
}
