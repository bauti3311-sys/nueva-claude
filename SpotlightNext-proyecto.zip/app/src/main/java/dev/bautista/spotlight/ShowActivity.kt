package dev.bautista.spotlight

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings

/** Activity invisible: abre la barra Spotlight y se cierra. La usa el segundo ícono y el mosaico de ajustes rápidos. */
class ShowActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Settings.canDrawOverlays(this)) {
            OverlayService.start(this, true)
        } else {
            startActivity(Intent(this, MainActivity::class.java))
        }
        finish()
        overridePendingTransition(0, 0)
    }
}
