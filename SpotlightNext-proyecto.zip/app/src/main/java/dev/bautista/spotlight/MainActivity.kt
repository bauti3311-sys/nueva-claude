package dev.bautista.spotlight

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Panel de control: enciende la superposición y muestra el estado REAL de cada permiso. */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = Color.rgb(10, 13, 16)
        window.navigationBarColor = Color.rgb(10, 13, 16)
    }

    override fun onResume() {
        super.onResume()
        // Si el usuario ya la había encendido, la reanudamos sola.
        if (prefs.serviceWanted && Perms.overlay(this) && !OverlayService.running) {
            OverlayService.start(this, false)
        }
        setContentView(buildUi())
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        setContentView(buildUi())
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        col.addView(text("Spotlight Next", 30f, Ui.TEXT, true))
        col.addView(text("Versión nativa · datos reales de tu tablet", 14f, Ui.MUTED, false, bottom = 20))

        // --- interruptor principal
        val on = OverlayService.running
        val main = card()
        val sw = Switch(this)
        sw.text = "Superposición activa (burbuja sobre cualquier app)"
        sw.textSize = 16f
        sw.setTextColor(Ui.TEXT)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                if (!Perms.overlay(this)) {
                    startActivity(Perms.overlayIntent(this))
                    Toast.makeText(this, "Activá «Permitir sobre otras apps» y volvé", Toast.LENGTH_LONG).show()
                } else if (!OverlayService.running) {
                    OverlayService.start(this, false)
                }
            } else {
                OverlayService.stop(this)
            }
        }
        main.addView(sw)
        main.addView(text("Una burbuja flotante abre la barra de búsqueda. Mantenela presionada para volver a este panel.", 12f, Ui.MUTED, false, top = 6))
        main.addView(button("Abrir la barra ahora", true) {
            if (!Perms.overlay(this)) {
                startActivity(Perms.overlayIntent(this))
            } else {
                OverlayService.start(this, true)
            }
        })
        col.addView(main)

        // --- opciones
        val opts = card()
        val s1 = Switch(this)
        s1.text = "Mostrar la burbuja flotante"
        s1.setTextColor(Ui.TEXT)
        s1.isChecked = prefs.bubbleVisible
        s1.setOnCheckedChangeListener { _, c -> prefs.bubbleVisible = c }
        opts.addView(s1)
        val s2 = Switch(this)
        s2.text = "Iniciar al encender la tablet"
        s2.setTextColor(Ui.TEXT)
        s2.isChecked = prefs.autostart
        s2.setOnCheckedChangeListener { _, c -> prefs.autostart = c }
        opts.addView(s2)
        opts.addView(button("Olvidar apps más usadas", false) {
            prefs.clearUsage()
            Toast.makeText(this, "Listo", Toast.LENGTH_SHORT).show()
        })
        col.addView(opts)

        // --- permisos reales
        col.addView(text("Permisos (estado real)", 18f, Ui.TEXT, true, top = 16, bottom = 6))
        col.addView(perm(
            "Superposición sobre otras apps", "Imprescindible: dibuja la burbuja y la barra encima de todo.",
            Perms.overlay(this)
        ) { startActivity(Perms.overlayIntent(this)) })
        col.addView(perm(
            "Notificaciones de Spotlight", "Mantiene el servicio vivo y muestra el aviso «Spotlight activo».",
            Perms.postNotifications(this)
        ) { if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) })
        col.addView(perm(
            "Acceso a notificaciones y multimedia",
            "Muestra tus notificaciones reales, copia códigos 2FA y controla Spotify/YouTube. " +
                "Si el interruptor sale en gris: Ajustes → Apps → Spotlight Next → ⋮ → «Permitir ajustes restringidos».",
            Perms.listener(this)
        ) { startActivity(Perms.listenerIntent()) })
        col.addView(perm(
            "Contactos", "Busca tus contactos por nombre.", Perms.contacts(this)
        ) { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 2) })
        col.addView(perm(
            "Calendario", "Busca tus eventos y muestra los próximos.", Perms.calendar(this)
        ) { requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 3) })
        col.addView(perm(
            "Acceso a todos los archivos", "Busca PDF, documentos y descargas por nombre.", Perms.files(this)
        ) {
            if (Build.VERSION.SDK_INT >= 30) startActivity(Perms.allFilesIntent(this))
            else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 4)
        })
        col.addView(perm(
            "Ubicación aproximada", "Solo para el clima de tu zona.", Perms.location(this)
        ) { requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 5) })
        col.addView(perm(
            "Modificar ajustes del sistema", "Para cambiar brillo y rotación desde la barra.", Perms.writeSettings(this)
        ) { startActivity(Perms.writeSettingsIntent(this)) })
        col.addView(perm(
            "Sin restricciones de batería", "Evita que Samsung cierre el servicio en segundo plano.",
            Perms.batteryUnrestricted(this)
        ) { startActivity(Perms.batteryIntent(this)) })

        col.addView(text(
            "Qué hay en la barra: apps instaladas, contactos, calendario, archivos, notificaciones, " +
                "portapapeles (solo en memoria), calculadora, volumen, brillo, rotación, ajustes, " +
                "dólar (dolarapi.com) y clima (Open-Meteo). Probá escribir: dolar, clima, 2+2, notif, agenda, codigo.",
            12f, Ui.MUTED, false, top = 16
        ))
        col.addView(text("También hay un mosaico «Spotlight» para agregar a los ajustes rápidos y un segundo ícono «Spotlight» en el launcher.", 12f, Ui.MUTED, false, top = 8, bottom = 24))

        val dm = resources.displayMetrics
        val w = minOf(dm.widthPixels - dp(32), dp(680))
        val frame = FrameLayout(this)
        frame.addView(col, FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        frame.setPadding(0, dp(24), 0, 0)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.rgb(10, 13, 16))
        sv.addView(frame)
        return sv
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.background = Ui.round(Ui.CARD, dp(16).toFloat(), Ui.STROKE, dp(1))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        c.layoutParams = lp
        return c
    }

    private fun perm(title: String, desc: String, ok: Boolean, grant: () -> Unit): View {
        val c = card()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val t = text(title, 15f, Ui.TEXT, true)
        row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val st = TextView(this)
        st.text = if (ok) "✔ Concedido" else "✖ Falta"
        st.textSize = 12f
        st.typeface = Typeface.DEFAULT_BOLD
        st.setTextColor(if (ok) Ui.ACCENT else Ui.DANGER)
        row.addView(st)
        c.addView(row)
        c.addView(text(desc, 12f, Ui.MUTED, false, top = 4))
        if (!ok) c.addView(button("Conceder", true, grant))
        return c
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean, top: Int = 0, bottom: Int = 0): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(top), 0, dp(bottom))
        t.layoutParams = lp
        return t
    }

    private fun button(label: String, filled: Boolean, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = label
        b.textSize = 14f
        b.gravity = Gravity.CENTER
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(if (filled) Color.rgb(6, 20, 14) else Ui.TEXT)
        b.setPadding(dp(16), dp(10), dp(16), dp(10))
        b.background = if (filled) Ui.round(Ui.ACCENT, dp(12).toFloat())
        else Ui.round(Color.argb(30, 255, 255, 255), dp(12).toFloat(), Ui.STROKE, dp(1))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        b.layoutParams = lp
        b.setOnClickListener {
            try { onClick() } catch (e: Exception) { Toast.makeText(this, e.message ?: "Error", Toast.LENGTH_SHORT).show() }
        }
        return b
    }
}
