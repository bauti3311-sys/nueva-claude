package dev.bautista.spotlight

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View

object Ui {
    val BG = Color.argb(246, 16, 20, 24)
    val CARD = Color.rgb(28, 33, 40)
    val STROKE = Color.argb(64, 255, 255, 255)
    val TEXT = Color.rgb(236, 240, 244)
    val MUTED = Color.rgb(140, 150, 162)
    val ACCENT = Color.rgb(16, 185, 129)
    val ACCENT_SOFT = Color.argb(70, 16, 185, 129)
    val DANGER = Color.rgb(244, 63, 94)

    fun round(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setColor(color)
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    fun oval(color: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
        }
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun View.dp(v: Int): Int = context.dp(v)
