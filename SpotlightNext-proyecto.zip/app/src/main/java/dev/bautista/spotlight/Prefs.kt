package dev.bautista.spotlight

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("spotlight", Context.MODE_PRIVATE)

    /** El usuario encendió la superposición (se reanuda sola al abrir la app o al reiniciar). */
    var serviceWanted: Boolean
        get() = sp.getBoolean("service_wanted", false)
        set(v) { sp.edit().putBoolean("service_wanted", v).apply() }

    var bubbleVisible: Boolean
        get() = sp.getBoolean("bubble", true)
        set(v) { sp.edit().putBoolean("bubble", v).apply() }

    var autostart: Boolean
        get() = sp.getBoolean("autostart", true)
        set(v) { sp.edit().putBoolean("autostart", v).apply() }

    var bubbleX: Int
        get() = sp.getInt("bubble_x", -1)
        set(v) { sp.edit().putInt("bubble_x", v).apply() }

    var bubbleY: Int
        get() = sp.getInt("bubble_y", -1)
        set(v) { sp.edit().putInt("bubble_y", v).apply() }

    /** Contador de uso por clave ("app:com.whatsapp") para ordenar sugerencias. */
    fun usage(key: String): Int = loadUsage().optInt(key, 0)

    fun bump(key: String) {
        val o = loadUsage()
        o.put(key, o.optInt(key, 0) + 1)
        sp.edit().putString("usage", o.toString()).apply()
    }

    fun clearUsage() {
        sp.edit().remove("usage").apply()
    }

    private fun loadUsage(): JSONObject =
        try { JSONObject(sp.getString("usage", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
}
