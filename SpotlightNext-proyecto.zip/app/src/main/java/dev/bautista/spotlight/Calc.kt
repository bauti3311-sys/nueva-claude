package dev.bautista.spotlight

import java.math.BigDecimal
import java.math.MathContext
import java.util.Locale

object Calc {
    private val allowed = Regex("[0-9a-z+\\-*/^().%]+")
    private val looksMath = Regex("[0-9)%][+\\-*/^x]|[a-z]+\\(|[0-9)]%")

    /** Devuelve el resultado ya formateado, o null si el texto no es una cuenta. */
    fun tryEval(raw: String): String? {
        val s = raw.lowercase(Locale.ROOT)
            .replace(" ", "")
            .replace(",", ".")
            .replace("×", "*")
            .replace("÷", "/")
        if (s.length < 2 || !allowed.matches(s) || !looksMath.containsMatchIn(s)) return null
        return try {
            val p = Parser(s)
            val v = p.expr()
            if (p.pos != s.length || v.isNaN() || v.isInfinite()) null else fmt(v)
        } catch (e: Exception) {
            null
        }
    }

    fun fmt(v: Double): String {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        return BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
    }

    private class Parser(val s: String) {
        var pos = 0

        fun peek(): Char = if (pos < s.length) s[pos] else '\u0000'

        fun expr(): Double {
            var v = term()
            while (true) {
                val c = peek()
                if (c == '+') { pos++; v += term() }
                else if (c == '-') { pos++; v -= term() }
                else break
            }
            return v
        }

        fun term(): Double {
            var v = unary()
            while (true) {
                val c = peek()
                if (c == '*' || c == 'x') { pos++; v *= unary() }
                else if (c == '/') { pos++; v /= unary() }
                else break
            }
            return v
        }

        fun unary(): Double {
            val c = peek()
            if (c == '-') { pos++; return -unary() }
            if (c == '+') { pos++; return unary() }
            return power()
        }

        fun power(): Double {
            val base = postfix()
            if (peek() == '^') {
                pos++
                return Math.pow(base, unary())
            }
            return base
        }

        fun postfix(): Double {
            var v = atom()
            while (peek() == '%') { pos++; v /= 100.0 }
            return v
        }

        fun atom(): Double {
            val c = peek()
            if (c == '(') {
                pos++
                val v = expr()
                expect(')')
                return v
            }
            if (c.isDigit() || c == '.') {
                val st = pos
                while (peek().isDigit() || peek() == '.') pos++
                return s.substring(st, pos).toDouble()
            }
            if (c.isLetter()) {
                val st = pos
                while (peek().isLetter()) pos++
                val id = s.substring(st, pos)
                when (id) {
                    "pi" -> return Math.PI
                    "e" -> return Math.E
                }
                expect('(')
                val a = expr()
                expect(')')
                return when (id) {
                    "sqrt", "raiz" -> Math.sqrt(a)
                    "sin" -> Math.sin(a)
                    "cos" -> Math.cos(a)
                    "tan" -> Math.tan(a)
                    "log" -> Math.log10(a)
                    "ln" -> Math.log(a)
                    "abs" -> Math.abs(a)
                    "round" -> Math.rint(a)
                    "floor" -> Math.floor(a)
                    "ceil" -> Math.ceil(a)
                    else -> throw IllegalArgumentException("fn")
                }
            }
            throw IllegalArgumentException("tok")
        }

        fun expect(c: Char) {
            if (peek() != c) throw IllegalArgumentException("expected $c")
            pos++
        }
    }
}
