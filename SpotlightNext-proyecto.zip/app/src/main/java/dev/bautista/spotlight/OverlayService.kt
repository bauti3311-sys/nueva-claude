package dev.bautista.spotlight

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.provider.Settings

/**
 * Servicio en primer plano que dibuja sobre cualquier app (TYPE_APPLICATION_OVERLAY):
 *  - una burbuja flotante arrastrable
 *  - la barra Spotlight a pantalla completa con fondo tenue
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_START = "dev.bautista.spotlight.START"
        const val ACTION_SHOW = "dev.bautista.spotlight.SHOW"
        const val ACTION_STOP = "dev.bautista.spotlight.STOP"
        private const val CHANNEL = "spotlight_overlay"
        private const val NOTIF_ID = 41

        @Volatile var running = false

        fun start(ctx: Context, show: Boolean) {
            val i = Intent(ctx, OverlayService::class.java).setAction(if (show) ACTION_SHOW else ACTION_START)
            ctx.startForegroundService(i)
        }

        fun stop(ctx: Context) {
            Prefs(ctx).serviceWanted = false
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var engine: SearchEngine
    private val handler = Handler(Looper.getMainLooper())

    private var bubble: BubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: SpotlightPanel? = null

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { hidePanel() }
    }
    private val pkgChanged = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { engine.refreshApps() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        engine = SearchEngine(this, prefs)
        engine.refreshApps()
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
        val pf = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgChanged, pf)
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())

        if (intent?.action == ACTION_STOP) {
            prefs.serviceWanted = false
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Perms.overlayIntent(this))
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        prefs.serviceWanted = true
        showBubble()
        if (intent?.action == ACTION_SHOW) showPanel()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val v = bubble
        val lp = bubbleLp
        if (v != null && lp != null) {
            clampBubble(lp)
            try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
        }
    }

    override fun onDestroy() {
        hidePanel()
        hideBubble()
        try { unregisterReceiver(screenOff) } catch (e: Exception) {}
        try { unregisterReceiver(pkgChanged) } catch (e: Exception) {}
        running = false
        super.onDestroy()
    }

    // ---------------------------------------------------------------- notificación

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Spotlight activo", NotificationManager.IMPORTANCE_MIN)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val showPi = PendingIntent.getForegroundService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_SHOW), fl
        )
        val stopPi = PendingIntent.getForegroundService(
            this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), fl
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle("Spotlight Next")
            .setContentText("Tocá para buscar sobre cualquier app")
            .setContentIntent(showPi)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_tile), "Detener", stopPi).build())
            .build()
    }

    // ---------------------------------------------------------------- pantalla

    private fun screen(): Point {
        val p = Point()
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            p.set(b.width(), b.height())
        } else {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealSize(p)
        }
        return p
    }

    private fun overlayType(): Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    // ---------------------------------------------------------------- burbuja

    private class BubbleView(c: Context) : View(c) {
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(238, 16, 20, 24) }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); color = Ui.ACCENT
        }
        private val glass = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat(); color = Color.WHITE
            strokeCap = Paint.Cap.ROUND
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val cx = w / 2f
            val cy = height / 2f
            val r = w / 2f - dp(2)
            canvas.drawCircle(cx, cy, r, bg)
            canvas.drawCircle(cx, cy, r, ring)
            val lr = w * 0.17f
            canvas.drawCircle(cx - lr * 0.35f, cy - lr * 0.35f, lr, glass)
            canvas.drawLine(cx + lr * 0.6f, cy + lr * 0.6f, cx + lr * 1.5f, cy + lr * 1.5f, glass)
        }
    }

    private fun clampBubble(lp: WindowManager.LayoutParams) {
        val s = screen()
        lp.x = lp.x.coerceIn(0, (s.x - lp.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (s.y - lp.height).coerceAtLeast(0))
    }

    private fun showBubble() {
        if (bubble != null || panel != null || !prefs.bubbleVisible) return
        val size = dp(52)
        val v = BubbleView(this)
        v.alpha = 0.92f
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        val s = screen()
        lp.x = if (prefs.bubbleX >= 0) prefs.bubbleX else s.x - size
        lp.y = if (prefs.bubbleY >= 0) prefs.bubbleY else (s.y * 0.35f).toInt()
        clampBubble(lp)

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        v.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            var startX = 0
            var startY = 0
            var moved = false
            var longFired = false
            val longRun = Runnable {
                if (!moved) {
                    longFired = true
                    startActivity(Intent(this@OverlayService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }

            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y
                        moved = false; longFired = false
                        handler.postDelayed(longRun, 650)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                            moved = true
                            handler.removeCallbacks(longRun)
                        }
                        if (moved) {
                            lp.x = (startX + dx).toInt()
                            lp.y = (startY + dy).toInt()
                            clampBubble(lp)
                            try { wm.updateViewLayout(view, lp) } catch (ex: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        handler.removeCallbacks(longRun)
                        if (moved) snap(view, lp) else if (!longFired) showPanel()
                    }
                    MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRun)
                }
                return true
            }
        })

        try {
            wm.addView(v, lp)
            bubble = v
            bubbleLp = lp
        } catch (e: Exception) {
        }
    }

    private fun snap(view: View, lp: WindowManager.LayoutParams) {
        val s = screen()
        val target = if (lp.x + lp.width / 2 < s.x / 2) 0 else s.x - lp.width
        ValueAnimator.ofInt(lp.x, target).apply {
            duration = 180
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try { wm.updateViewLayout(view, lp) } catch (e: Exception) {}
            }
            start()
        }
        prefs.bubbleX = target
        prefs.bubbleY = lp.y
    }

    private fun hideBubble() {
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bubble = null
        bubbleLp = null
    }

    // ---------------------------------------------------------------- barra

    private fun showPanel() {
        if (panel != null) return
        hideBubble()
        val themed: Context = ContextThemeWrapper(this, android.R.style.Theme_Material)
        val p = SpotlightPanel(themed, engine) { hidePanel() }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        try {
            wm.addView(p, lp)
            panel = p
        } catch (e: Exception) {
            showBubble()
        }
    }

    private fun hidePanel() {
        val p = panel ?: return
        panel = null
        try { wm.removeView(p) } catch (e: Exception) {}
        handler.post { showBubble() }
    }
}
