# Spotlight Next (nativa)

App Android nativa (Kotlin, sin librerías externas) con barra de búsqueda superpuesta sobre cualquier app.
Todo lo que muestra son datos reales del dispositivo; no hay datos de demostración.

Compilar: ver `build.yml` (GitHub Actions) o abrir la carpeta en Android Studio y ejecutar `assembleRelease`.
